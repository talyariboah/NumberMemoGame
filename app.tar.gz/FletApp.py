import flet as ft
import random
import time

number_sequence = []
user_sequence = []
sequence_length = 1

def generate_sequence(length):
    return [random.randint(10, 99) for _ in range(length)]

def display_sequence(page):
    for number in number_sequence:
        page.clean()
        page.add(ft.Container(
            content=ft.Text(
                "\n\n\nRemember this number:",
                style=ft.TextStyle(size=30, weight="bold", color=ft.colors.PINK_900),
                text_align=ft.TextAlign.CENTER
            ),
            alignment=ft.alignment.center
        ))
        page.update()
        page.add(ft.Container(
            content=ft.Text(
                str(number),
                style=ft.TextStyle(size=120, weight="bold", color=ft.colors.PINK_900),
                text_align=ft.TextAlign.CENTER
            ),
            alignment=ft.alignment.center
        ))
        page.update()
        time.sleep(1.5)
    page.clean()  # Clean the page after displaying the sequence

def start_game(page):
    global number_sequence, user_sequence, sequence_length
    number_sequence = generate_sequence(sequence_length)
    user_sequence = [None] * sequence_length

    page.clean()

    display_sequence(page)

    page.add(ft.Container(
        content=ft.Text(
            "\n\n\nEnter the numbers:",
            style=ft.TextStyle(size=30, weight="bold", color=ft.colors.PINK_900),
            text_align=ft.TextAlign.CENTER
        ),
        alignment=ft.alignment.center
    ))
    page.add(ft.Container(
        content=ft.Text(
            "\n"
        ),
        alignment=ft.alignment.center
    ))
    page.update()
    
    text_field = ft.TextField(
        label="Number",
        on_change=auto_space_input,
        color=ft.colors.PINK_900
    )
    page.add(ft.Container(
        content=text_field,
        alignment=ft.alignment.center
    ))
    page.add(ft.Container(
        content=ft.Text(
            "\n"
        ),
        alignment=ft.alignment.center
    ))
    page.add(ft.Container(
        content=ft.ElevatedButton("Submit", on_click=lambda e: check_sequence(e, text_field), bgcolor=ft.colors.PINK_300, color=ft.colors.PINK_900),
        alignment=ft.alignment.center
    ))

def auto_space_input(event):
    value = event.control.value.replace(" ", "")
    spaced_value = ""
    for i in range(len(value)):
        spaced_value += value[i]
        if (i + 1) % 2 == 0 and i != len(value) - 1:
            spaced_value += " "
    event.control.value = spaced_value
    event.control.update()

def check_sequence(event, text_field):
    global sequence_length
    user_input = text_field.value.strip()
    user_sequence = list(map(int, user_input.split()))
    print(user_sequence, number_sequence)
    if user_sequence == number_sequence:
        sequence_length += 1
        event.page.clean()
        event.page.add(ft.Container(
            content=ft.Text(
                "\n\n\n\nCorrect! Get ready for the next numbers.",
                style=ft.TextStyle(size=30, color=ft.colors.PINK_900),
                text_align=ft.TextAlign.CENTER
            ),
            alignment=ft.alignment.center
        ))
        event.page.add(ft.Container(
            content=ft.Text(
                "\n"
            ),
            alignment=ft.alignment.center
        ))
    else:
        event.page.clean()
        event.page.add(ft.Container(
            content=ft.Text(
                "\n\n\n\nIncorrect! Try again.",
                style=ft.TextStyle(size=30, color=ft.colors.PINK_900),
                text_align=ft.TextAlign.CENTER
            ),
            alignment=ft.alignment.center
        ))
        sequence_length = 1
        event.page.add(ft.Container(
            content=ft.Text(
                "\n"
            ),
            alignment=ft.alignment.center
        ))
    event.page.add(ft.Container(
        content=ft.ElevatedButton("Start Again", on_click=lambda e: start_game(e.page), bgcolor=ft.colors.PINK_300, color=ft.colors.PINK_900),
        alignment=ft.alignment.center
    ))

def main(page):
    page.title = "Number Memory Game"
    page.bgcolor = ft.colors.PINK_50  # Set the background color to light pink
    page.add(ft.Container(
        content=ft.Text(
            "\nWelcome to the Number Memory Game!",
            style=ft.TextStyle(size=40, weight="bold", color=ft.colors.PINK_900),
            text_align=ft.TextAlign.CENTER
        ),
        alignment=ft.alignment.center
    ))
    page.add(ft.Container(
        content=ft.Text(
            "\n"
        ),
        alignment=ft.alignment.center
    ))
    page.add(ft.Container(
        content=ft.ElevatedButton("Start Game", on_click=lambda e: start_game(page), bgcolor=ft.colors.PINK_300, color=ft.colors.PINK_900),
        alignment=ft.alignment.center
    ))

ft.app(target=main)
